-- RLS & Policy SQL for ZestyChat
-- Run this in Supabase SQL editor (replace schema if needed).

-- 1) Enable RLS on relevant tables
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.moderation_actions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.broadcasts ENABLE ROW LEVEL SECURITY;

-- 2) profiles: allow users to insert their own profile row (when they sign up)
CREATE POLICY "Profiles: insert own profile" ON public.profiles
  FOR INSERT
  WITH CHECK (id = auth.uid());

-- Allow users to select profiles (public facing)
CREATE POLICY "Profiles: select public" ON public.profiles
  FOR SELECT
  USING (true);

-- Allow users to update only their own non-role fields (you may adjust)
CREATE POLICY "Profiles: update own profile" ON public.profiles
  FOR UPDATE
  USING (id = auth.uid())
  WITH CHECK (id = auth.uid());

-- 3) messages policies
-- Insert: allow only authenticated users whose profile is not banned and not muted
CREATE POLICY "Messages: insert if not banned/muted and user_id matches" ON public.messages
  FOR INSERT
  TO authenticated
  WITH CHECK (
    (user_id = auth.uid())
    AND (
      SELECT (banned_until IS NULL OR banned_until < now()) AND (muted_until IS NULL OR muted_until < now())
      FROM public.profiles p WHERE p.id = auth.uid()
    )
  );

-- Select: public messages (non-private)
CREATE POLICY "Messages: select public (non-private, not deleted)" ON public.messages
  FOR SELECT
  USING (is_private = false AND is_deleted = false);

-- Select: private messages only visible to sender or recipient (authenticated users)
CREATE POLICY "Messages: select private for participants" ON public.messages
  FOR SELECT
  TO authenticated
  USING (
    is_private = false OR (is_private = true AND (user_id = auth.uid() OR to_user_id = auth.uid()))
  );

-- Update: allow users to update their own messages (e.g., edit) if desired
CREATE POLICY "Messages: update own message" ON public.messages
  FOR UPDATE
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

-- Update: allow mods/admins/owner to update messages (delete/mark warned)
CREATE POLICY "Messages: update by mods/admin/owner" ON public.messages
  FOR UPDATE
  USING (
    EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.role IN ('mod','admin','owner'))
  );

-- 4) moderation_actions
-- Restrict reading/writing of moderation_actions to mods/admin/owner
CREATE POLICY "Moderation: insert by staff" ON public.moderation_actions
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.role IN ('mod','admin','owner'))
  );

CREATE POLICY "Moderation: select by staff" ON public.moderation_actions
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.role IN ('mod','admin','owner'))
  );

-- Note: Edge Functions using SUPABASE_SERVICE_ROLE_KEY bypass RLS so they can write as needed.

-- 5) broadcasts
-- Allow owner to insert broadcasts
CREATE POLICY "Broadcasts: insert by owner" ON public.broadcasts
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.role = 'owner')
  );

-- Select active broadcasts only (this returns only currently active announcements)
CREATE POLICY "Broadcasts: select active only" ON public.broadcasts
  FOR SELECT
  USING (starts_at <= now() AND (ends_at IS NULL OR ends_at >= now()));

-- 6) Storage (attachments) policies
-- Supabase uses storage.objects in the storage schema.
-- The following policy allows insertions to storage.objects for:
--  - profile pictures (metadata->>'type' = 'profile_picture') by the authenticated user
--  - attachments only if the uploader is verified (metadata assumed to contain uploader id)
-- Run this in SQL editor (storage schema exists in your project)

-- Enable RLS on storage.objects (if not already)
ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

-- Allow upload of profile pictures by authenticated user (ex: metadata->>'user_id' = auth.uid())
CREATE POLICY "Storage: insert profile pictures by owner" ON storage.objects
  FOR INSERT
  TO authenticated
  WITH CHECK (
    (metadata->>'type' = 'profile_picture' AND metadata->>'user_id' = auth.uid())
    OR
    -- allow chat attachments only if uploader is verified
    ((metadata->>'type' IS NOT NULL AND metadata->>'user_id' = auth.uid())
      AND (
        (SELECT verified FROM public.profiles p WHERE p.id = auth.uid()) = true
      )
    )
  );

-- Allow select/download of storage objects that are public (for example, profile pictures or attachments that you intentionally make public)
CREATE POLICY "Storage: select public or same user" ON storage.objects
  FOR SELECT
  USING (
    -- allow if object is not marked private OR the requester is the uploader
    ( (metadata->>'private') IS NULL OR (metadata->>'private') = 'false' )
    OR (metadata->>'user_id' = auth.uid())
  );

-- 7) Provide index and helper (optional)
-- You can create indexes to speed up checks
CREATE INDEX IF NOT EXISTS idx_profiles_verified ON public.profiles (verified);
CREATE INDEX IF NOT EXISTS idx_profiles_banned_until ON public.profiles (banned_until);
CREATE INDEX IF NOT EXISTS idx_messages_room_created_at ON public.messages (room_id, created_at);