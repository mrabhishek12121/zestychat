```markdown
# Supabase Edge Functions for ZestyChat

Files:
- moderation/index.ts — endpoint to perform moderation actions (mute/ban/kick/delete/warn/toggle-verified/toggle-admin).
- broadcast/index.ts — endpoint for owner to schedule broadcasts.

Environment variables (set on Supabase Functions dashboard; DO NOT commit):
- SUPABASE_URL
- SUPABASE_SERVICE_ROLE_KEY

Deploy:
1. Place the functions in your repo under supabase/functions/<name>/index.ts
2. From your local machine, install supabase CLI and run:
   supabase login
   supabase link --project-ref <your-project-ref>
   supabase functions deploy moderation --project-ref <your-project-ref>
   supabase functions deploy broadcast --project-ref <your-project-ref>
3. In the Supabase dashboard, configure function environment variables (SUPABASE_SERVICE_ROLE_KEY and SUPABASE_URL).
4. Call the function with an Authorization header (Bearer <access_token>) from an authenticated admin/mod/owner user (the function validates the caller's token and role).

Notes:
- Edge Functions use the service role client to perform privileged writes to the DB. The service role bypasses RLS — this is intentional: the functions enforce permissions server-side.
- For "kick" you may want to revoke user refresh tokens or actively disconnect a user's realtime session. If you want that behavior, tell me and I'll add the token-invalidation call for your supabase-js version.
- Always rotate the service role key if it is ever exposed.
```