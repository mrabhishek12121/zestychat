import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import { createClient } from "https://cdn.jsdelivr.net/npm/@supabase/supabase-js/+esm";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
  throw new Error("Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY env vars");
}

const supabaseAdmin = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, { auth: { persistSession: false } });

serve(async (req) => {
  try {
    if (req.method !== "POST") return new Response(JSON.stringify({ error: "Only POST allowed" }), { status: 405 });

    const authHeader = req.headers.get("authorization") || "";
    const token = authHeader.replace(/^Bearer\s+/i, "");
    if (!token) return new Response(JSON.stringify({ error: "Missing Authorization header" }), { status: 401 });

    const { data: userData, error: userErr } = await supabaseAdmin.auth.getUser(token);
    if (userErr || !userData?.user) {
      return new Response(JSON.stringify({ error: "Invalid token" }), { status: 401 });
    }
    const callerId = userData.user.id;

    const { data: callerProfile, error: profErr } = await supabaseAdmin.from("profiles").select("role").eq("id", callerId).single();
    if (profErr || !callerProfile) return new Response(JSON.stringify({ error: "Caller profile not found" }), { status: 403 });

    if (callerProfile.role !== "owner") return new Response(JSON.stringify({ error: "Only owner can schedule broadcast" }), { status: 403 });

    const body = await req.json().catch(() => null);
    if (!body || !body.message) return new Response(JSON.stringify({ error: "message is required" }), { status: 400 });

    const message = String(body.message).slice(0, 2000);
    const starts_at = body.starts_at ? new Date(body.starts_at).toISOString() : new Date().toISOString();
    const ends_at = body.ends_at ? new Date(body.ends_at).toISOString() : null;

    const { error: insertErr } = await supabaseAdmin.from("broadcasts").insert({
      message,
      starts_at,
      ends_at,
      created_by: callerId
    });

    if (insertErr) throw insertErr;

    // Realtime will notify subscribers automatically via the DB change
    return new Response(JSON.stringify({ ok: true, message: "Broadcast scheduled" }), { status: 200 });
  } catch (err: any) {
    console.error(err);
    return new Response(JSON.stringify({ error: err?.message ?? String(err) }), { status: 500 });
  }
});