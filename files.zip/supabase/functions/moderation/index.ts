import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import { createClient } from "https://cdn.jsdelivr.net/npm/@supabase/supabase-js/+esm";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
  throw new Error("Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY env vars");
}

const supabaseAdmin = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, {
  auth: { persistSession: false }
});

serve(async (req) => {
  try {
    if (req.method !== "POST") return new Response(JSON.stringify({ error: "Only POST allowed" }), { status: 405 });

    const authHeader = req.headers.get("authorization") || "";
    const token = authHeader.replace(/^Bearer\s+/i, "");

    if (!token) return new Response(JSON.stringify({ error: "Missing Authorization header" }), { status: 401 });

    // Validate token and get user
    const { data: userData, error: userErr } = await supabaseAdmin.auth.getUser(token);
    if (userErr || !userData?.user) {
      return new Response(JSON.stringify({ error: "Invalid token" }), { status: 401 });
    }
    const callerId = userData.user.id;

    // Get caller profile and role
    const { data: callerProfile, error: profErr } = await supabaseAdmin
      .from("profiles")
      .select("*")
      .eq("id", callerId)
      .single();

    if (profErr || !callerProfile) {
      return new Response(JSON.stringify({ error: "Caller profile not found" }), { status: 403 });
    }

    const body = await req.json().catch(() => null);
    if (!body) return new Response(JSON.stringify({ error: "Invalid JSON" }), { status: 400 });

    const { action, target_user_id, message_id, reason } = body;

    // Allowed roles map
    const role = callerProfile.role;
    const isOwner = role === "owner";
    const isAdmin = role === "admin" || isOwner;
    const isMod = role === "mod" || isAdmin;

    // Helper to write moderation action record (service role client)
    async function recordAction(actionType: string, extras: any = {}) {
      const insertBody = {
        target_user: target_user_id ?? null,
        performed_by: callerId,
        action_type: actionType,
        reason: reason ?? null,
        expires_at: extras.expires_at ?? null,
        metadata: extras.metadata ?? null
      };
      const { error: insertErr } = await supabaseAdmin.from("moderation_actions").insert(insertBody);
      if (insertErr) throw insertErr;
    }

    // Permission checks per action
    if (action === "mute" || action === "ban" || action === "kick" || action === "warn" || action === "delete_message" || action === "toggle-verified" || action === "toggle-admin") {
      if (!(isMod || isAdmin || isOwner)) {
        return new Response(JSON.stringify({ error: "Insufficient permissions" }), { status: 403 });
      }
    } else {
      return new Response(JSON.stringify({ error: "Unknown action" }), { status: 400 });
    }

    // Compute expires_at for 1 day actions
    const oneDayMs = 24 * 60 * 60 * 1000;
    const expiresAt = new Date(Date.now() + oneDayMs).toISOString();

    // Handle actions
    if (action === "mute") {
      // Set muted_until on target profile and record action
      const { error: uErr } = await supabaseAdmin
        .from("profiles")
        .update({ muted_until: expiresAt })
        .eq("id", target_user_id);
      if (uErr) throw uErr;
      await recordAction("mute", { expires_at: expiresAt });
      return new Response(JSON.stringify({ ok: true, action: "muted", expires_at: expiresAt }), { status: 200 });
    }

    if (action === "ban") {
      const { error: uErr } = await supabaseAdmin
        .from("profiles")
        .update({ banned_until: expiresAt })
        .eq("id", target_user_id);
      if (uErr) throw uErr;
      await recordAction("ban", { expires_at: expiresAt });
      return new Response(JSON.stringify({ ok: true, action: "banned", expires_at: expiresAt }), { status: 200 });
    }

    if (action === "kick") {
      // Kick: add moderation action record; optional: you can also revoke refresh tokens (see notes)
      await recordAction("kick", { expires_at: expiresAt });
      // Optional: revoke tokens (commented out; enable only if you want to call admin endpoint that exists in your supabase-js version)
      // await supabaseAdmin.auth.admin.invalidateUserRefreshTokens(target_user_id);
      return new Response(JSON.stringify({ ok: true, action: "kicked", expires_at: expiresAt }), { status: 200 });
    }

    if (action === "delete_message") {
      if (!message_id) return new Response(JSON.stringify({ error: "message_id required" }), { status: 400 });
      // Mark message as deleted
      const { error: delErr } = await supabaseAdmin.from("messages").update({ is_deleted: true }).eq("id", message_id);
      if (delErr) throw delErr;
      await recordAction("delete_message", { metadata: { message_id } });
      return new Response(JSON.stringify({ ok: true, action: "deleted_message", message_id }), { status: 200 });
    }

    if (action === "warn") {
      await recordAction("warn", {});
      return new Response(JSON.stringify({ ok: true, action: "warned" }), { status: 200 });
    }

    if (action === "toggle-verified") {
      if (!isAdmin && !isOwner) return new Response(JSON.stringify({ error: "Only admins/owner may toggle verified" }), { status: 403 });
      // Toggle verified flag
      const { data: targetProfile, error: tgErr } = await supabaseAdmin.from("profiles").select("verified").eq("id", target_user_id).single();
      if (tgErr) throw tgErr;
      const newVerified = !targetProfile.verified;
      const { error: upErr } = await supabaseAdmin.from("profiles").update({ verified: newVerified }).eq("id", target_user_id);
      if (upErr) throw upErr;
      await recordAction("toggle-verified", { metadata: { newVerified } });
      return new Response(JSON.stringify({ ok: true, verified: newVerified }), { status: 200 });
    }

    if (action === "toggle-admin") {
      if (!isOwner) return new Response(JSON.stringify({ error: "Only owner may promote/demote admins" }), { status: 403 });
      const { data: targetProfile, error: tgErr } = await supabaseAdmin.from("profiles").select("role").eq("id", target_user_id).single();
      if (tgErr) throw tgErr;
      const newRole = targetProfile.role === "admin" ? "user" : "admin";
      const { error: upErr } = await supabaseAdmin.from("profiles").update({ role: newRole }).eq("id", target_user_id);
      if (upErr) throw upErr;
      await recordAction("toggle-admin", { metadata: { newRole } });
      return new Response(JSON.stringify({ ok: true, role: newRole }), { status: 200 });
    }

    return new Response(JSON.stringify({ error: "Unhandled case" }), { status: 500 });
  } catch (err: any) {
    console.error(err);
    return new Response(JSON.stringify({ error: err?.message ?? String(err) }), { status: 500 });
  }
});