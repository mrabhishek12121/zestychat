-- Basic schema for ZestyChat

-- profiles table (linked to auth.users via id)
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  avatar_url text,
  verified boolean default false,
  role text default 'user', -- 'owner', 'admin', 'mod', 'user'
  muted_until timestamp with time zone,
  banned_until timestamp with time zone,
  created_at timestamptz default now()
);

-- rooms
create table if not exists rooms (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  name text not null,
  type text not null, -- 'global', 'language', 'staff'
  description text,
  created_at timestamptz default now()
);

-- messages
create table if not exists messages (
  id uuid primary key default gen_random_uuid(),
  room_id uuid references rooms(id) on delete cascade,
  user_id uuid references profiles(id),
  content text,
  is_private boolean default false,
  to_user_id uuid references profiles(id),
  is_deleted boolean default false,
  is_warned boolean default false,
  metadata jsonb,
  created_at timestamptz default now()
);

-- attachments (images/gifs) (upload handled via Storage)
create table if not exists attachments (
  id uuid primary key default gen_random_uuid(),
  message_id uuid references messages(id) on delete cascade,
  url text not null,
  type text,
  created_at timestamptz default now()
);

-- moderation actions (ban, mute, kick)
create table if not exists moderation_actions (
  id uuid primary key default gen_random_uuid(),
  target_user uuid references profiles(id),
  performed_by uuid references profiles(id),
  action_type text not null, -- 'ban','mute','kick','delete_message'
  reason text,
  expires_at timestamptz,
  created_at timestamptz default now()
);

-- simple presence table (can be used or use realtime presence API)
create table if not exists user_presence (
  user_id uuid references profiles(id) primary key,
  is_online boolean default false,
  last_seen timestamptz default now()
);

-- Seed basic rooms (global, a sample language room, staff)
insert into rooms (slug, name, type, description) values
('global', 'Global Room', 'global', 'Open chat for all users')
on conflict (slug) do nothing;

insert into rooms (slug, name, type, description) values
('any-language', 'Any Language', 'language', 'Open language chat')
on conflict (slug) do nothing;

insert into rooms (slug, name, type, description) values
('staff', 'Staff Room', 'staff', 'Staff and moderators only')
on conflict (slug) do nothing;