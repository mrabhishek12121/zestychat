import React, { useEffect, useRef, useState } from 'react';
import { supabase } from '../lib/supabaseClient';

type Props = {
  me: any;
  target: any | null;
  onClose?: ()=>void;
}

export default function PMPanel({ me, target, onClose }: Props) {
  const [messages, setMessages] = useState<any[]>([]);
  const [text, setText] = useState('');
  const [full, setFull] = useState(false);
  const boxRef = useRef<HTMLDivElement|null>(null);

  useEffect(() => {
    if (!target) return;
    // load PM history: messages where is_private and (user_id = me.id and to_user_id = target.id) or vice versa
    (async ()=>{
      const { data } = await supabase.from('messages').select('*')
        .or(`and(is_private.eq.true,user_id.eq.${me?.id},to_user_id.eq.${target.id}),and(is_private.eq.true,user_id.eq.${target.id},to_user_id.eq.${me?.id})`)
        .order('created_at', { ascending:true }).limit(200);
      setMessages(data ?? []);
    })();

    const channel = supabase.channel(`pm:${[me?.id,target?.id].sort().join(':')}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, payload => {
        const m = payload.new;
        if (m.is_private && (m.user_id === me.id || m.to_user_id === me.id)) {
          setMessages(prev => [...prev, m]);
        }
      }).subscribe();

    return ()=>{ supabase.removeChannel(channel); };
  }, [me, target]);

  async function send() {
    if (!target || !text.trim()) return;
    await supabase.from('messages').insert({
      room_id: null,
      user_id: me.id,
      content: text,
      is_private: true,
      to_user_id: target.id
    });
    setText('');
  }

  if (!target) return null;

  return (
    <div ref={boxRef} className={`pm-panel ${full ? 'full' : ''}`} role="dialog" aria-label={`Private chat with ${target.username}`}>
      <div className="pm-header">
        <div>
          <strong>PM • {target.username}</strong>
          <div className="small">Tap expand to make full screen</div>
        </div>
        <div style={{display:'flex', gap:8, alignItems:'center'}}>
          <button onClick={()=>setFull(f=>!f)} aria-label="Expand">{full ? 'Collapse' : 'Expand'}</button>
          <button onClick={onClose}>Close</button>
        </div>
      </div>

      <div className="pm-messages" style={{flex:1}}>
        {messages.map(m => (
          <div key={m.id} style={{display:'flex', flexDirection: m.user_id === me.id ? 'row-reverse' : 'row', gap:8}}>
            <div style={{maxWidth:'70%'}} className="bubble">
              <div style={{fontSize:12, color:'var(--muted)'}}>{m.user_id === me.id ? 'You' : target.username} • {new Date(m.created_at).toLocaleTimeString()}</div>
              <div style={{marginTop:6}}>{m.content}</div>
            </div>
          </div>
        ))}
      </div>

      <div style={{padding:10, borderTop:'1px solid rgba(255,255,255,0.02)', display:'flex', gap:8}}>
        <input value={text} onChange={e=>setText(e.target.value)} placeholder="Write a private message..." />
        <button onClick={send}>Send</button>
      </div>
    </div>
  );
}