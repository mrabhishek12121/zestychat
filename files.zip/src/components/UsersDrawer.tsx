import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabaseClient';

type Props = {
  me:any;
  onOpenPM?: (user:any)=>void;
  onClickUserMenu?: (user:any, rect:DOMRect)=>void;
}

export default function UsersDrawer({ me, onOpenPM, onClickUserMenu }: Props) {
  const [users, setUsers] = useState<any[]>([]);

  useEffect(()=>{
    async function load(){
      const { data } = await supabase.from('profiles').select('*').order('username', {ascending:true});
      setUsers(data ?? []);
    }
    load();

    const chan = supabase.channel('public:profiles')
      .on('postgres_changes', { event: '*', schema:'public', table:'profiles' }, payload=>{
        // naive refresh
        load();
      }).subscribe();

    return ()=> supabase.removeChannel(chan);
  },[]);

  return (
    <div className="users-drawer" role="complementary" aria-label="Users drawer">
      <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:8}}>
        <strong>Users</strong>
        <div className="small">{users.length} members</div>
      </div>

      <div style={{display:'flex', flexDirection:'column', gap:8}}>
        {users.map(u => (
          <div key={u.id} style={{display:'flex', justifyContent:'space-between', alignItems:'center', gap:8}}>
            <div style={{display:'flex', gap:8, alignItems:'center'}}>
              <div style={{width:36,height:36,borderRadius:8,background: u.verified ? 'linear-gradient(135deg,var(--accent),var(--accent-2))' : 'rgba(255,255,255,0.03)', display:'flex', alignItems:'center', justifyContent:'center', color:'#fff', fontWeight:700}}>
                {u.username?.charAt(0)?.toUpperCase() ?? '?'}
              </div>
              <div>
                <div style={{fontWeight:700}}>{u.username}</div>
                <div className="small">{u.verified ? 'Verified' : 'Unverified'}</div>
              </div>
            </div>

            <div style={{display:'flex', gap:8}}>
              <button onClick={()=>onOpenPM?.(u)}>PM</button>
              <button onClick={(e)=>{
                const rect = (e.target as HTMLElement).getBoundingClientRect();
                onClickUserMenu?.(u, rect);
              }}>⋯</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}