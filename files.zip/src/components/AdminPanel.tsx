import React from 'react';

type Props = {
  currentUser:any;
  onAction?: (action:string, payload?:any)=>void;
}

export default function AdminPanel({ currentUser, onAction }: Props) {
  if (!currentUser) return null;
  const isAdmin = currentUser.role === 'admin' || currentUser.role === 'owner';

  if (!isAdmin) return null;

  return (
    <div className="admin-card">
      <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
        <div>
          <div style={{fontWeight:800}}>Admin Controls</div>
          <div className="small">Quick moderation and tools</div>
        </div>
        <div style={{display:'flex', gap:8}}>
          <button onClick={()=>onAction?.('open-moderation-log')} className="small">Logs</button>
        </div>
      </div>

      <div style={{height:12}} />

      <div className="admin-actions">
        <button onClick={()=>onAction?.('clear-room')} className="small">Clear Room (delete recent messages)</button>
        <button onClick={()=>onAction?.('lock-room')} className="small">Lock Room</button>
        <button onClick={()=>onAction?.('unlock-room')} className="small">Unlock Room</button>
        <button onClick={()=>onAction?.('broadcast')} className="small">Send Broadcast</button>
      </div>
    </div>
  );
}