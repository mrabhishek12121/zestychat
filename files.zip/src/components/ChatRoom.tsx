import React, { useEffect, useState, useRef } from 'react';
import { supabase } from '../lib/supabaseClient';

// Minimal ChatRoom component with realtime messages and PM panel
export default function ChatRoom({ session }: { session: any }) {
  const user = session.user;
  const [rooms, setRooms] = useState<any[]>([]);
  const [activeRoom, setActiveRoom] = useState<string>('global');
  const [messages, setMessages] = useState<any[]>([]);
  const [text, setText] = useState('');
  const [pmOpenTo, setPmOpenTo] = useState<any | null>(null);
  const [unreadPMs, setUnreadPMs] = useState(0);
  const pmRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    // load rooms
    supabase.from('rooms').select('*').then(r => setRooms(r.data ?? []));

    // load recent messages for global room
    fetchMessages(activeRoom);

    // realtime subscription for messages
    const messageSub = supabase.channel('public:messages')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, payload => {
        const msg = payload.new;
        if (msg.room_id === activeRoom) {
          setMessages(prev => [...prev, msg]);
        }
        // if private message to me -> increment unread and show red dot
        if (msg.is_private && msg.to_user_id === user?.id) {
          setUnreadPMs(n => n + 1);
        }
      }).subscribe();

    return () => {
      supabase.removeChannel(messageSub);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeRoom]);

  async function fetchMessages(roomSlug: string) {
    // resolve room id
    const room = (await supabase.from('rooms').select('*').eq('slug', roomSlug).single()).data;
    if (!room) return;
    const resp = await supabase.from('messages').select('*').eq('room_id', room.id).order('created_at', { ascending: true }).limit(200);
    setMessages(resp.data ?? []);
  }

  async function sendMessage() {
    if (!text.trim()) return;
    const room = (await supabase.from('rooms').select('*').eq('slug', activeRoom).single()).data;
    if (!room) return;
    // check if user is banned/muted (basic client check; enforce on server/RLS)
    const { data: profile } = await supabase.from('profiles').select('*').eq('id', user.id).single();
    if (profile?.muted_until && new Date(profile.muted_until) > new Date()) {
      return alert('You are muted and cannot send messages.');
    }
    await supabase.from('messages').insert({
      room_id: room.id,
      user_id: user.id,
      content: text,
      is_private: pmOpenTo ? true : false,
      to_user_id: pmOpenTo ? pmOpenTo.id : null
    });
    setText('');
  }

  function openPM(targetUser: any) {
    setPmOpenTo(targetUser);
    setUnreadPMs(0);
  }

  return (
    <div style={{ display: 'flex', height: '100vh' }}>
      <aside style={{ width: 240, borderRight: '1px solid #ddd', padding: 12 }}>
        <h3>Rooms</h3>
        <ul>
          {rooms.map(r => (
            <li key={r.id}>
              <button onClick={() => { setActiveRoom(r.slug); fetchMessages(r.slug); }}>{r.name}</button>
            </li>
          ))}
        </ul>

        <h4>Users (online/offline)</h4>
        <div>
          <button onClick={() => { /* toggle list of online users */ }}>☰ Show users</button>
        </div>
      </aside>

      <main style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
        {/* owner broadcast area -- can be shown/hidden */}
        <div id="owner-banner" style={{ background: '#fffae6', padding: 8, display: 'none' }}>
          Owner broadcast message will appear here for configured time
        </div>

        <div style={{ flex: 1, overflow: 'auto', padding: 12 }}>
          {messages.map(m => (
            <div key={m.id} style={{ padding: 6, borderBottom: '1px solid #eee' }}>
              <strong>{m.user_id}</strong> <small>{new Date(m.created_at).toLocaleTimeString()}</small>
              <div>{m.content}</div>
            </div>
          ))}
        </div>

        <div style={{ display: 'flex', padding: 12, borderTop: '1px solid #ddd' }}>
          <input style={{ flex: 1 }} value={text} onChange={e => setText(e.target.value)} placeholder="Type a message" />
          <button onClick={sendMessage}>Send</button>
        </div>
      </main>

      {/* Private message box (top-right) */}
      <div ref={pmRef} style={{ position: 'fixed', top: 16, right: 16, width: pmOpenTo ? 480 : 320, maxHeight: '80vh', border: '1px solid #ccc', background: 'white', padding: 8 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <strong>PM {pmOpenTo ? pmOpenTo.username : ''}</strong>
          <div style={{ display: 'flex', gap: 8 }}>
            <span style={{ width: 10, height: 10, borderRadius: 5, background: unreadPMs ? 'red' : 'transparent' }} />
            <button onClick={() => setPmOpenTo(null)}>Close</button>
          </div>
        </div>
        {/* messages for this PM would be streamed similarly */}
      </div>
    </div>
  );
}