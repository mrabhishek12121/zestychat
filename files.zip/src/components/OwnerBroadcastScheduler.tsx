import React, { useState } from 'react';
import { supabase } from '../lib/supabaseClient';

type Props = {
  currentUser:any;
  onScheduled?: ()=>void;
}

export default function OwnerBroadcastScheduler({ currentUser, onScheduled }: Props) {
  const [message, setMessage] = useState('');
  const [startsAt, setStartsAt] = useState<string>('');
  const [endsAt, setEndsAt] = useState<string>('');
  const isOwner = currentUser?.role === 'owner';

  if (!isOwner) return null;

  async function schedule() {
    if (!message.trim()) return alert('Enter a message');
    try {
      await supabase.from('broadcasts').insert({
        message,
        starts_at: startsAt ? new Date(startsAt).toISOString() : new Date().toISOString(),
        ends_at: endsAt ? new Date(endsAt).toISOString() : new Date(Date.now() + 1000*60*60).toISOString(),
        created_by: currentUser.id
      });
      setMessage(''); setStartsAt(''); setEndsAt('');
      onScheduled?.();
      alert('Broadcast scheduled');
    } catch (err:any) {
      console.error(err);
      alert('Failed to schedule broadcast');
    }
  }

  return (
    <div className="admin-card broadcast-form" style={{marginTop:8}}>
      <div style={{fontWeight:800}}>Owner Broadcast</div>
      <textarea rows={3} value={message} onChange={e=>setMessage(e.target.value)} placeholder="Announcement to show at top of screen" />
      <div className="row" style={{marginTop:8}}>
        <input type="datetime-local" value={startsAt} onChange={e=>setStartsAt(e.target.value)} />
        <input type="datetime-local" value={endsAt} onChange={e=>setEndsAt(e.target.value)} />
      </div>
      <div style={{marginTop:8}}>
        <button onClick={schedule}>Schedule Broadcast</button>
      </div>
    </div>
  );
}