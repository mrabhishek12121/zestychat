import React from 'react';
import { supabase } from '../lib/supabaseClient';

type Props = {
  target: any; // profile row
  currentUser: any;
  onClose?: ()=>void;
  onOpenPM?: (target:any)=>void;
  onModerationAction?: (action:string, target:any)=>void;
}

export default function UserMenu({ target, currentUser, onClose, onOpenPM, onModerationAction }: Props) {
  const isOwner = currentUser?.role === 'owner';
  const isAdmin = currentUser?.role === 'admin' || isOwner;
  const isMod = currentUser?.role === 'mod' || isAdmin;

  async function perform(action: string) {
    // UI-level write to moderation_actions; enforcement must be done server-side (Edge Function) with service role
    try {
      await supabase.from('moderation_actions').insert({
        target_user: target.id,
        performed_by: currentUser.id,
        action_type: action,
        reason: `${action} via UI by ${currentUser.id}`,
        expires_at: action === 'kick' || action === 'mute' || action === 'ban' ? new Date(Date.now() + 24*60*60*1000).toISOString() : null
      });
      onModerationAction?.(action, target);
    } catch (err:any) {
      console.error(err);
      alert('Action failed: ' + (err.message || err));
    } finally {
      onClose?.();
    }
  }

  async function toggleVerify() {
    try{
      await supabase.from('profiles').update({ verified: !target.verified }).eq('id', target.id);
      onModerationAction?.('toggle-verified', target);
    }catch(e:any){ console.error(e); alert('Failed to toggle verified'); }
    onClose?.();
  }

  async function toggleAdmin() {
    if (!isOwner) return alert('Only owner can promote/demote admins.');
    try{
      await supabase.from('profiles').update({ role: target.role === 'admin' ? 'user' : 'admin' }).eq('id', target.id);
      onModerationAction?.('toggle-admin', target);
    }catch(e:any){ console.error(e); alert('Failed to change role'); }
    onClose?.();
  }

  return (
    <div className="user-menu" role="menu" aria-label={`Actions for ${target.username}`}>
      <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
        <div>
          <div style={{fontWeight:700}}>{target.username}</div>
          <div className="small">{target.verified ? 'Verified' : 'Unverified'} • {target.role}</div>
        </div>
        <div style={{textAlign:'right'}}><small className="small">{target?.last_seen ? new Date(target.last_seen).toLocaleString() : ''}</small></div>
      </div>

      <button onClick={()=>{ onOpenPM?.(target); onClose?.(); }}>Open PM</button>

      {/* moderator actions */}
      {(isMod || isAdmin) && (
        <>
          <button onClick={()=>perform('delete_message')}>Delete last message</button>
          <button onClick={()=>perform('warn')}>Warn user</button>
        </>
      )}

      {isAdmin && (
        <div style={{display:'flex', gap:8}}>
          <button onClick={()=>perform('kick')}>Kick 1 day</button>
          <button onClick={()=>perform('mute')}>Mute 1 day</button>
          <button onClick={()=>perform('ban')}>Ban 1 day</button>
        </div>
      )}

      {isOwner && (
        <div style={{display:'flex', gap:8}}>
          <button onClick={toggleAdmin}>{target.role === 'admin' ? 'Demote admin' : 'Make admin'}</button>
          <button onClick={toggleVerify}>{target.verified ? 'Unverify' : 'Verify'}</button>
        </div>
      )}

      <div style={{height:1, background:'rgba(255,255,255,0.02)', margin:'6px 0'}} />

      <button onClick={()=>{ navigator.clipboard?.writeText(target.id); alert('Copied ID'); onClose?.(); }}>Copy ID</button>
      <button onClick={()=>onClose?.()}>Close</button>
    </div>
  );
}